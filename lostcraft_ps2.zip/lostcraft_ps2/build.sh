#!/bin/sh
# Requer docker. Gera lostcraft.elf e lostcraft.iso
set -e
python3 tools/conv.py
docker run --rm -v "$PWD":/src -w /src ps2dev/ps2dev:latest make
mkdir -p iso && cp lostcraft.elf iso/LOSTCRAFT.ELF
printf 'BOOT2 = cdrom0:\\LOSTCRAFT.ELF;1\r\nVER = 1.00\r\nVMODE = NTSC\r\n' > iso/SYSTEM.CNF
(genisoimage -o lostcraft.iso iso || mkisofs -o lostcraft.iso iso)
