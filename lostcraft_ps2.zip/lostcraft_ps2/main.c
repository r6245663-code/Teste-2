// LostCraft PS2 - sandbox 2D original (codigo proprio) usando terrain.png (16x16 tiles)
#include <kernel.h>
#include <sifrpc.h>
#include <loadfile.h>
#include <libpad.h>
#include <gsKit.h>
#include <dmaKit.h>
#include <math.h>
#include <string.h>

extern unsigned char terrain_rgba[];

#define TS 32            // tile na tela (16px do atlas x2)
#define W 256
#define H 64
#define SW 640
#define SH 448
#define PW 22
#define PH 56
enum { AIR, GRASS, DIRT, STONE, SAND, LOG, PLANKS, LEAVES, COBBLE, NB };
// indice do tile no atlas (16x16 tiles, 0..255). AJUSTE AQUI se algum bloco sair errado.
static const int tile_of[NB] = { -1, 3, 2, 1, 18, 20, 4, 52, 16 };
static const int hot[8] = { GRASS, DIRT, STONE, SAND, LOG, PLANKS, LEAVES, COBBLE };

static unsigned char world[H][W];
static unsigned rng = 12345;
static unsigned rnd(void) { rng = rng * 1664525u + 1013904223u; return rng >> 16; }
static int surf(int x) { int y = 0; while (y < H && world[y][x] == AIR) y++; return y; }

static void gen(void) {
    int x, y;
    memset(world, 0, sizeof(world));
    for (x = 0; x < W; x++) {
        int h = 28 + (int)(5 * sinf(x * 0.06f) + 3 * sinf(x * 0.17f + 1));
        for (y = h; y < H; y++) {
            unsigned char b = (y == h) ? GRASS : (y < h + 4) ? DIRT : STONE;
            if (y > h + 6 && y < H - 1 && sinf(x * 0.3f) * sinf(y * 0.4f) > 0.8f) b = AIR;
            world[y][x] = b;
        }
    }
    for (x = 3; x < W - 3; x += 4 + rnd() % 5) {
        int h = surf(x), dx, dy;
        if (world[h][x] != GRASS) continue;
        for (dy = 1; dy <= 4; dy++) world[h - dy][x] = LOG;
        for (dy = 4; dy <= 6; dy++)
            for (dx = -2; dx <= 2; dx++)
                if (world[h - dy][x + dx] == AIR) world[h - dy][x + dx] = LEAVES;
    }
}

static int solid(int tx, int ty) {
    if (tx < 0 || tx >= W) return 1;
    if (ty < 0) return 0;
    if (ty >= H) return 1;
    return world[ty][tx] != AIR;
}
static int hitbox(float x, float y) {
    int x0 = (int)floorf(x / TS), x1 = (int)floorf((x + PW - 0.01f) / TS);
    int y0 = (int)floorf(y / TS), y1 = (int)floorf((y + PH - 0.01f) / TS), i, j;
    for (j = y0; j <= y1; j++) for (i = x0; i <= x1; i++) if (solid(i, j)) return 1;
    return 0;
}

static GSGLOBAL *gs;
static GSTEXTURE tex;
static char padbuf[256] __attribute__((aligned(64)));
#define COL(r, g, b) GS_SETREG_RGBAQ(r, g, b, 0x80, 0x00)
#define WHITE GS_SETREG_RGBAQ(0x80, 0x80, 0x80, 0x80, 0x00)

static void rect(float x1, float y1, float x2, float y2, u64 c) { gsKit_prim_sprite(gs, x1, y1, x2, y2, 2, c); }
static void block(int b, float x, float y, float s) {
    int t = tile_of[b], u = (t % 16) * 16, v = (t / 16) * 16;
    gsKit_prim_sprite_texture(gs, &tex, x, y, u, v, x + s, y + s, u + 16, v + 16, 1, WHITE);
}

int main(void) {
    float px, py, vx = 0, vy = 0; int face = 1, sel = 0, cd = 0, i, j;
    u32 old = 0;
    SifInitRpc(0);
    SifLoadModule("rom0:SIO2MAN", 0, NULL);
    SifLoadModule("rom0:PADMAN", 0, NULL);
    padInit(0); padPortOpen(0, 0, padbuf);
    while (padGetState(0, 0) != PAD_STATE_STABLE && padGetState(0, 0) != PAD_STATE_FINDCTP1) {}
    padSetMainMode(0, 0, PAD_MMODE_DUALSHOCK, PAD_MMODE_LOCK);

    gs = gsKit_init_global();
    gs->PSM = GS_PSM_CT24; gs->PSMZ = GS_PSMZ_16S;
    gs->ZBuffering = GS_SETTING_OFF; gs->DoubleBuffering = GS_SETTING_ON;
    gs->PrimAlphaEnable = GS_SETTING_ON;
    dmaKit_init(D_CTRL_RELE_OFF, D_CTRL_MFD_OFF, D_CTRL_STS_UNSPEC, D_CTRL_STD_OFF, D_CTRL_RCYC_8, 1 << DMA_CHANNEL_GIF);
    dmaKit_chan_init(DMA_CHANNEL_GIF);
    gsKit_init_screen(gs);
    gsKit_mode_switch(gs, GS_ONESHOT);
    gsKit_set_primalpha(gs, GS_SETREG_ALPHA(0, 1, 0, 1, 0), 0);
    tex.Width = 256; tex.Height = 256; tex.PSM = GS_PSM_CT32;
    tex.Mem = (void *)terrain_rgba; tex.Filter = GS_FILTER_NEAREST;
    tex.Vram = gsKit_vram_alloc(gs, gsKit_texture_size(256, 256, GS_PSM_CT32), GSKIT_ALLOC_USERBUFFER);
    gsKit_texture_upload(gs, &tex);

    gen();
    px = (W / 2) * TS; py = (surf(W / 2) - 3) * TS;

    for (;;) {
        struct padButtonStatus b; u32 pad = 0, np; float lx = 0, rx = 0, ry = 0;
        if (padRead(0, 0, &b) != 0) {
            pad = 0xffff ^ b.btns;
            lx = (b.ljoy_h - 128) / 128.0f; rx = (b.rjoy_h - 128) / 128.0f; ry = (b.rjoy_v - 128) / 128.0f;
        }
        np = pad & ~old; old = pad;
        if (np & PAD_R1) sel = (sel + 1) % 8;
        if (np & PAD_L1) sel = (sel + 7) % 8;

        vx = 0;
        if ((pad & PAD_LEFT) || lx < -0.3f) vx = -3;
        if ((pad & PAD_RIGHT) || lx > 0.3f) vx = 3;
        if (vx) face = vx > 0 ? 1 : -1;
        if ((np & PAD_CROSS) && hitbox(px, py + 1)) vy = -9.5f;
        vy += 0.5f; if (vy > 12) vy = 12;
        { int n = (int)fabsf(vx), k; float s = vx < 0 ? -1 : 1;
          for (k = 0; k < n; k++) { if (!hitbox(px + s, py)) px += s; else break; } }
        { int n = (int)fabsf(vy), k; float s = vy < 0 ? -1 : 1;
          for (k = 0; k < n; k++) { if (!hitbox(px, py + s)) py += s; else { vy = 0; break; } } }
        if (py > H * TS) { px = (W / 2) * TS; py = 0; vy = 0; }

        // alvo: stick direito (ate 5 tiles) ou bloco a frente
        float cx = px + PW / 2, cy = py + PH / 2, tx, ty;
        if (fabsf(rx) > 0.3f || fabsf(ry) > 0.3f) { tx = cx + rx * 160; ty = cy + ry * 160; }
        else { tx = cx + face * TS; ty = cy; }
        int bx = (int)floorf(tx / TS), by = (int)floorf(ty / TS);
        int ok = bx >= 0 && bx < W && by >= 0 && by < H;
        if (cd > 0) cd--;
        if (ok && cd == 0) {
            if ((pad & PAD_SQUARE) && world[by][bx] != AIR) { world[by][bx] = AIR; cd = 8; }
            else if ((pad & PAD_CIRCLE) && world[by][bx] == AIR) {
                world[by][bx] = hot[sel];
                if (hitbox(px, py)) world[by][bx] = AIR; else cd = 8;
            }
        }

        int camX = (int)(px + PW / 2 - SW / 2), camY = (int)(py + PH / 2 - SH / 2);
        if (camX < 0) camX = 0; if (camX > W * TS - SW) camX = W * TS - SW;
        if (camY < 0) camY = 0; if (camY > H * TS - SH) camY = H * TS - SH;

        gsKit_clear(gs, GS_SETREG_RGBAQ(0x6e, 0xb4, 0xff, 0x00, 0x00));
        for (j = camY / TS; j <= (camY + SH) / TS && j < H; j++)
            for (i = camX / TS; i <= (camX + SW) / TS && i < W; i++)
                if (world[j][i]) block(world[j][i], i * TS - camX, j * TS - camY, TS);
        // jogador
        { float sx = px - camX, sy = py - camY;
          rect(sx, sy, sx + PW, sy + 18, COL(0xe0, 0xb0, 0x80));
          rect(sx, sy + 18, sx + PW, sy + 38, COL(0x20, 0xa0, 0xb0));
          rect(sx, sy + 38, sx + PW, sy + PH, COL(0x40, 0x40, 0xa0)); }
        // cursor
        if (ok) { float sx = bx * TS - camX, sy = by * TS - camY;
            rect(sx, sy, sx + TS, sy + 2, COL(255, 255, 0)); rect(sx, sy + TS - 2, sx + TS, sy + TS, COL(255, 255, 0));
            rect(sx, sy, sx + 2, sy + TS, COL(255, 255, 0)); rect(sx + TS - 2, sy, sx + TS, sy + TS, COL(255, 255, 0)); }
        // hotbar
        for (i = 0; i < 8; i++) {
            rect(8 + i * 40, 8, 48 + i * 40, 48, i == sel ? COL(255, 255, 0) : COL(0, 0, 0));
            rect(11 + i * 40, 11, 45 + i * 40, 45, COL(60, 60, 60));
            block(hot[i], 12 + i * 40, 12, 32);
        }
        gsKit_queue_exec(gs);
        gsKit_sync_flip(gs);
    }
    return 0;
}
