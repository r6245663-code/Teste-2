# terrain.png -> terrain.c (RGBA32, GS alpha 0..128). Rode: python3 tools/conv.py
from PIL import Image
im=Image.open('tools/terrain.png').convert('RGBA').resize((256,256),Image.NEAREST)
d=bytearray()
for r,g,b,a in im.getdata(): d+=bytes((r,g,b,min(128,(a+1)//2)))
open('terrain.c','w').write('unsigned char terrain_rgba[%d] __attribute__((aligned(128))) = {%s};\n'%(len(d),','.join(map(str,d))))
